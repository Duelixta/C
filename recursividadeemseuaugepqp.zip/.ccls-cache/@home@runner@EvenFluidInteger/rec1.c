/*#include <stdio.h>

int somaDigitos(int n) {
if (n==0) {
  return 0;
} // como é inteiro, não ligamos para virgula é como se fosse um inteiro tmbém
return (n % 10) + somaDigitos(n / 10);
}
int main() {
  int numero;

  // Leitura do número do usuário
  printf("Digite um número inteiro positivo: ");
  scanf("%d", &numero);

  if (numero < 0) {
      printf("Por favor, insira um número positivo.\n");
      return 1;  // Termina o programa em caso de entrada inválida
  }

  // Chama a função recursiva e exibe o resultado
  int resultado = somaDigitos(numero);
  printf("A soma dos dígitos de %d é: %d\n", numero, resultado);

  return 0;
}*/