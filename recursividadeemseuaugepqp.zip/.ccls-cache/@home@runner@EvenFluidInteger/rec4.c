/* 02. Faça uma função recursiva para calcular a potência entre dois números inteiros x e y (pot = xy).
Não use a função pow ( ) pronta do C.*/

/*#include <stdio.h>

int potencia(int x, int y) {
  if (y == 0) {
    return 1;
  }
    return x * potencia(x,y - 1); // Y [E UM CONTADOR PUTA QUE PARIUY DESGRa  'plkosk,fq;']
}

int main() {
  int x,y;
  printf("Digite seu numerador e seu expoente(X e Y)\n");
  scanf("%d %d", &x, &y);

  int pot = potencia(x,y);
  printf("Seu result eh %d", pot);
  return 0;
}*/
