/*#include <stdio.h>

int SomaDigito(int n) {

  if (n==0) {
    return 0;
  }

  return (n%10) + SomaDigito(n/10);
}

int main() {
  int numero;
  printf("Somaremos os digitos do seu numero");
  scanf("%i",&numero);


int resultado = SomaDigito(numero);

  printf("A soma dos digitos do numero %i é = %i",numero,resultado);

  return 0;
}*/