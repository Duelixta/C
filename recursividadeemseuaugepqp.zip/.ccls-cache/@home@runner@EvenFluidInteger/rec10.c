/*#include <stdio.h>
#include <ctype.h>  // Para usar tolower() e isalnum()
#include <string.h> // Para usar strlen()

// Função recursiva para verificar se a substring é palíndromo
int verifica_palindromo(const char *texto, int inicio, int fim) {
    // Caso base: Se os índices se cruzarem ou forem iguais
    if (inicio >= fim) {
        return 1;  // É palíndromo
    }

    // Ignorar caracteres não alfanuméricos
    if (!isalnum(texto[inicio])) {
        return verifica_palindromo(texto, inicio + 1, fim);
    }
    if (!isalnum(texto[fim])) {
        return verifica_palindromo(texto, inicio, fim - 1);
    }

    // Comparar os caracteres
    if (tolower(texto[inicio]) != tolower(texto[fim])) {
        return 0;  // Não é palíndromo
    }

    // Chamar a função recursivamente para os próximos caracteres
    return verifica_palindromo(texto, inicio + 1, fim - 1);
}

// Função principal para testar a recursão
int eh_palindromo(const char *texto) {
    int tamanho = strlen(texto);
    return verifica_palindromo(texto, 0, tamanho - 1);
}

int main() {
    const char *teste1 = "josue";
    const char *teste2 = "arara";
    const char *teste3 = "12321!";

    printf("\"%s\" é palíndromo? %s\n", teste1, eh_palindromo(teste1) ? "Sim" : "Não");
    printf("\"%s\" é palíndromo? %s\n", teste2, eh_palindromo(teste2) ? "Sim" : "Não");
    printf("\"%s\" é palíndromo? %s\n", teste3, eh_palindromo(teste3) ? "Sim" : "Não");

    return 0;
}
*/