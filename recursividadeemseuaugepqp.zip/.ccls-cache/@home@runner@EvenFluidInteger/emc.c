/*#include <stdio.h>


void decrescente(int n) {

  if(n < 0) {
    return 0;
  }
  if (n%2 == 0){
    printf("%d", n);
  }

  decrescente (n - 2);
}


int main() {

int n;
  printf("Manda o numero ai");
  scanf("%d",&n);

  printf("juvgghj");
  decrescente(n);
}*/