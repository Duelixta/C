/*#include <stdio.h>

double calcularSerie(int n) {
    if (n == 2) {  
        return 1.0 / 2;
    }
    return ((n - 1) / (double)n) + calcularSerie(n - 2);
}

int main() {
    int n;


    do {
        printf("Digite um número par: ");
        scanf("%d", &n);
        if (n % 2 != 0) {
            printf("Por favor, insira um número PAR.\n");
        }
    } while (n % 2 != 0);  

    // Calcula e exibe o valor da série
    double resultado = calcularSerie(n);
    printf("O valor da série é: %.6f\n", resultado);

    return 0;
}
*/