/*#include <stdio.h>

// Função recursiva para calcular a série S = 2 + 5/2 + 10/3 + ... + (1 + n^2) / n
double serie(int n) {
    if (n == 1) {
        return 2.0;  // Caso base: S(1) = 2
    }
    // Passo recursivo: (1 + n^2) / n + serie(n - 1)
    return (1.0 + n * n) / n + serie(n - 1);
}

int main() {
    int n;

    printf("Digite um valor para n (> 0): ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Por favor, insira um número maior que 0.\n");
        return 1;
    }

    double resultado = serie(n);
    printf("O valor da série S(%d) é: %.6f\n", n, resultado);

    return 0;
}
*/