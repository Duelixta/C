/*#include <stdio.h>
#include <stdlib.h>


int Soma(int n) {

if(n == 0) {
    return 0;
}

return (n % 10) + Soma(n / 10);
}
int main() {

    int numero;
    printf("Digite um número, iremos somar seus digitos.");
    scanf("%i",&numero);


    int resultado = Soma(numero);
    printf("Seu resultado eh %i", resultado);

return 0;
}*/