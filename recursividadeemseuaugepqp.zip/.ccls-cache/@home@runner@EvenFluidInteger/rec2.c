/*05. Faça uma função recursiva que receba um número inteiro positivo par N e imprima todos os
números pares de 0 até N em ordem decrescente
#include <stdio.h>

int decrescente(int n) {
if(n < 0){
  return 0;
}
  return ((n) + decrescente(n - 2));
  
}

int main() {
  int numero;

    printf("Envie um numero para que somemos todos seus numeros anteriores pares até 0 \n");
    scanf("%d", &numero);

  int soma = decrescente(numero);
  printf("Seu resultado eh %d", soma);
  return 0;
}


  #include <stdio.h>

// Função recursiva para imprimir números pares de N até 0 em ordem decrescente
void imprimirParesDecrescente(int n) {
    if (n < 0) {  // Caso base: Se n for menor que 0, termina a recursão
        return;
    }
    printf("%d ", n);  // Imprime o número atual
    imprimirParesDecrescente(n - 2);  // Chamada recursiva para o próximo par
}

int main() {
    int n;

    // Solicita um número par positivo do usuário
    do {
        printf("Digite um número inteiro positivo e par: ");
        scanf("%d", &n);
        if (n < 0 || n % 2 != 0) {
            printf("Por favor, insira um número PAR e POSITIVO.\n");
        }
    } while (n < 0 || n % 2 != 0);  // Garante que a entrada é válida

    // Chama a função recursiva para imprimir os pares
    printf("Números pares de %d até 0:\n", n);
    imprimirParesDecrescente(n);

    return 0;
}
*/