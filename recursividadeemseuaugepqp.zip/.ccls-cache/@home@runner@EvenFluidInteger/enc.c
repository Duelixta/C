/*#include <stdio.h>

double serie(int n) {

  if (n == 1.0) {
    return 2.0;
  }
    return (1.0 + n * n) / n + serie(n - 1.0);
  }


int main() {
  int n;

  printf("Escolha um numero");
  scanf("%d", &n);

  double result = serie(n);

  printf("SNDFJWLASNFGL %lf", result);

  return 0;
}*/