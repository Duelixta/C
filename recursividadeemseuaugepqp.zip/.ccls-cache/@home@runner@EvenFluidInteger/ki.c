/*#include <stdio.h>

// Função recursiva para imprimir números pares em ordem decrescente
void imprimirParesDecrescente(int N) {
    if (N < 0) return;  // Caso base: quando N for menor que 0, para a recursão

    if (N % 2 == 0) {
        printf("%d ", N);  // Imprime N se for par
    }

    imprimirParesDecrescente(N - 2);  // Chamada recursiva com N - 2
}

int main() {
    int N;

    printf("Digite um número inteiro positivo par: ");
    scanf("%d", &N);

    printf("Números pares de %d até 0 em ordem decrescente:\n", N);
    imprimirParesDecrescente(N);

    return 0;
}
*/