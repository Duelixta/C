/*#include <stdio.h>


int Decrescente(int n) {
  if (n < 0) {
    return 0;
  }

printf("%i",n);
Decrescente(n - 2);
}


int main() {

  int num;
  printf("Preciso de um numero");
  scanf("%i", &num);
if(num%2 != 0) {
  printf("Preciso de um numero PAR");
  scanf("%i", &num);
}
  Decrescente(num);
return 0;
}
*/